import sqlite3
import os
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'chat.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    conn = get_db()
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_seen TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS conversation_participants (
            conversation_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            PRIMARY KEY (conversation_id, user_id)
        );

        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id INTEGER NOT NULL,
            sender_id INTEGER NOT NULL,
            content TEXT,
            message_type TEXT DEFAULT 'text',
            file_url TEXT,
            file_name TEXT,
            file_size INTEGER,
            duration REAL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, timestamp);
        CREATE INDEX IF NOT EXISTS idx_participants_user ON conversation_participants(user_id);
    ''')
    conn.commit()
    conn.close()

def register_user(username, password):
    conn = get_db()
    existing = conn.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
    if existing:
        conn.close()
        return False, "Username already exists"
    pwhash = generate_password_hash(password)
    conn.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)", (username, pwhash))
    conn.commit()
    conn.close()
    return True, None

def authenticate_user(username, password):
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    if not user:
        conn.close()
        return False, None, "User not found"
    if not check_password_hash(user['password_hash'], password):
        conn.close()
        return False, None, "Incorrect password"
    conn.execute("UPDATE users SET last_seen = ? WHERE id = ?", (datetime.now(), user['id']))
    conn.commit()
    conn.close()
    return True, user['id'], None

def search_users(query, current_user_id):
    conn = get_db()
    users = conn.execute(
        "SELECT id, username FROM users WHERE username LIKE ? AND id != ? LIMIT 50",
        (f"%{query}%", current_user_id)
    ).fetchall()
    conn.close()
    return [dict(u) for u in users]

def get_or_create_conversation(user1_id, user2_id):
    conn = get_db()
    existing = conn.execute("""
        SELECT c.id FROM conversations c
        WHERE EXISTS (
            SELECT 1 FROM conversation_participants
            WHERE conversation_id = c.id AND user_id = ?
        )
        AND EXISTS (
            SELECT 1 FROM conversation_participants
            WHERE conversation_id = c.id AND user_id = ?
        )
        AND (SELECT COUNT(*) FROM conversation_participants WHERE conversation_id = c.id) = 2
    """, (user1_id, user2_id)).fetchone()
    if existing:
        conn.close()
        return existing['id']
    cur = conn.execute("INSERT INTO conversations DEFAULT VALUES")
    conv_id = cur.lastrowid
    conn.execute("INSERT INTO conversation_participants (conversation_id, user_id) VALUES (?, ?)", (conv_id, user1_id))
    conn.execute("INSERT INTO conversation_participants (conversation_id, user_id) VALUES (?, ?)", (conv_id, user2_id))
    conn.commit()
    conn.close()
    return conv_id

def get_user_conversations(user_id):
    conn = get_db()
    rows = conn.execute("""
        SELECT c.id as conv_id,
               u.id as other_user_id, u.username as other_username,
               m.content as last_content, m.message_type as last_type,
               m.timestamp as last_time, m.file_url as last_file
        FROM conversations c
        JOIN conversation_participants cp1 ON cp1.conversation_id = c.id AND cp1.user_id = ?
        JOIN conversation_participants cp2 ON cp2.conversation_id = c.id AND cp2.user_id != ?
        JOIN users u ON u.id = cp2.user_id
        LEFT JOIN messages m ON m.id = (
            SELECT id FROM messages WHERE conversation_id = c.id
            ORDER BY timestamp DESC LIMIT 1
        )
        ORDER BY COALESCE(m.timestamp, c.created_at) DESC
    """, (user_id, user_id)).fetchall()
    conn.close()
    result = []
    for r in rows:
        conv = {
            'conversation_id': r['conv_id'],
            'other_user_id': r['other_user_id'],
            'other_username': r['other_username'],
        }
        if r['last_content']:
            conv['last_message'] = r['last_content']
        elif r['last_type'] == 'image':
            conv['last_message'] = '🖼️ Photo'
        elif r['last_type'] == 'video':
            conv['last_message'] = '🎬 Video'
        elif r['last_type'] == 'voice':
            conv['last_message'] = '🎤 Voice message'
        elif r['last_type'] == 'audio':
            conv['last_message'] = '🎵 Audio file'
        elif r['last_file']:
            conv['last_message'] = '📎 File'
        else:
            conv['last_message'] = ''
        conv['last_time'] = r['last_time'] if r['last_time'] else ''
        result.append(conv)
    return result

def get_conversation_messages(conv_id, limit=100, offset=0):
    conn = get_db()
    rows = conn.execute("""
        SELECT m.*, u.username as sender_username
        FROM messages m
        JOIN users u ON u.id = m.sender_id
        WHERE m.conversation_id = ?
        ORDER BY m.timestamp DESC
        LIMIT ? OFFSET ?
    """, (conv_id, limit, offset)).fetchall()
    conn.close()
    return [dict(r) for r in reversed(rows)]

def send_message(conv_id, sender_id, content=None, msg_type='text',
                 file_url=None, file_name=None, file_size=None, duration=None):
    conn = get_db()
    cur = conn.execute("""
        INSERT INTO messages (conversation_id, sender_id, content, message_type,
                              file_url, file_name, file_size, duration)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (conv_id, sender_id, content, msg_type, file_url, file_name, file_size, duration))
    msg_id = cur.lastrowid
    row = conn.execute("""
        SELECT m.*, u.username as sender_username
        FROM messages m JOIN users u ON u.id = m.sender_id
        WHERE m.id = ?
    """, (msg_id,)).fetchone()
    conn.commit()
    conn.close()
    return dict(row)

def get_user_by_id(user_id):
    conn = get_db()
    user = conn.execute("SELECT id, username, created_at, last_seen FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return dict(user) if user else None
