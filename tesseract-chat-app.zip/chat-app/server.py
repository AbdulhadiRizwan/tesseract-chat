import os
import time
import sys
from threading import Lock

from flask import Flask, request, jsonify, send_from_directory
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from werkzeug.utils import secure_filename

from database import init_db, register_user, authenticate_user, search_users
from database import get_or_create_conversation, get_user_conversations
from database import get_conversation_messages, send_message, get_user_by_id

app = Flask(__name__)
app.config['SECRET_KEY'] = 'tesseract-secret'
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif', 'mp4', 'webm', 'mov',
                      'mp3', 'wav', 'ogg', 'm4a'}

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

connected_users = {}
connected_lock = Lock()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_content_type(filename):
    ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
    types = {
        'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png',
        'gif': 'image/gif', 'mp4': 'video/mp4', 'webm': 'video/webm',
        'mov': 'video/quicktime', 'mp3': 'audio/mpeg', 'wav': 'audio/wav',
        'ogg': 'audio/ogg', 'm4a': 'audio/mp4'
    }
    return types.get(ext, 'application/octet-stream')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file'}), 400
    file = request.files['file']
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type'}), 400
    ts = str(int(time.time() * 1000))
    filename = secure_filename(ts + '_' + file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    size = os.path.getsize(filepath)
    return jsonify({
        'url': f'/uploads/{filename}',
        'filename': filename,
        'original_name': file.filename,
        'size': size,
        'content_type': get_content_type(filename)
    })

@app.route('/uploads/<filename>')
def serve_upload(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/health')
def health():
    return jsonify({'status': 'ok'})

@socketio.on('connect')
def handle_connect():
    pass

@socketio.on('disconnect')
def handle_disconnect():
    with connected_lock:
        user = connected_users.pop(request.sid, None)
    if user:
        socketio.emit('user_offline', {'username': user['username']})
        online = [u['username'] for u in connected_users.values()]
        emit('online_users', online)

@socketio.on('register')
def handle_register(data):
    success, error = register_user(data['username'], data['password'])
    emit('register_result', {'success': success, 'error': error})

@socketio.on('login')
def handle_login(data):
    success, user_id, error = authenticate_user(data['username'], data['password'])
    if success:
        user = get_user_by_id(user_id)
        with connected_lock:
            connected_users[request.sid] = {'user_id': user_id, 'username': user['username']}
        emit('login_result', {'success': True, 'user': user})
        socketio.emit('user_online', {'username': user['username']})
        online = [u['username'] for u in connected_users.values()]
        emit('online_users', online)
    else:
        emit('login_result', {'success': False, 'error': error})

@socketio.on('search_users')
def handle_search_users(data):
    with connected_lock:
        current = connected_users.get(request.sid)
    if not current:
        return
    results = search_users(data['query'], current['user_id'])
    online = {u['username'] for u in connected_users.values()}
    for r in results:
        r['online'] = r['username'] in online
    emit('search_results', {'users': results})

@socketio.on('get_conversations')
def handle_get_conversations():
    with connected_lock:
        current = connected_users.get(request.sid)
    if not current:
        return
    convs = get_user_conversations(current['user_id'])
    online = {u['username'] for u in connected_users.values()}
    for c in convs:
        c['other_online'] = c['other_username'] in online
    emit('conversations', {'conversations': convs})

@socketio.on('get_messages')
def handle_get_messages(data):
    with connected_lock:
        current = connected_users.get(request.sid)
    if not current:
        return
    msgs = get_conversation_messages(data['conversation_id'],
                                     data.get('limit', 100),
                                     data.get('offset', 0))
    emit('messages', {'messages': msgs})

@socketio.on('send_message')
def handle_send_message(data):
    with connected_lock:
        current = connected_users.get(request.sid)
    if not current:
        return
    msg = send_message(
        data['conversation_id'], current['user_id'],
        content=data.get('content'),
        msg_type=data.get('message_type', 'text'),
        file_url=data.get('file_url'),
        file_name=data.get('file_name'),
        file_size=data.get('file_size'),
        duration=data.get('duration')
    )
    emit('new_message', {'message': msg})
    socketio.emit('new_message', {'message': msg})

@socketio.on('start_conversation')
def handle_start_conversation(data):
    with connected_lock:
        current = connected_users.get(request.sid)
    if not current:
        return
    target_username = data['username']
    from database import get_db
    conn = get_db()
    target_row = conn.execute(
        "SELECT id FROM users WHERE username = ?", (target_username,)
    ).fetchone()
    conn.close()
    if not target_row:
        emit('conversation_started', {'success': False, 'error': 'User not found'})
        return
    conv_id = get_or_create_conversation(current['user_id'], target_row['id'])
    online = {u['username'] for u in connected_users.values()}
    emit('conversation_started', {
        'success': True,
        'conversation': {
            'conversation_id': conv_id,
            'other_user_id': target_row['id'],
            'other_username': target_username,
            'other_online': target_username in online
        }
    })

@socketio.on('get_online_users')
def handle_get_online_users():
    with connected_lock:
        online = [u['username'] for u in connected_users.values()]
    emit('online_users', online)

def run_server(host='0.0.0.0', port=5000, debug=False):
    init_db()
    socketio.run(app, host=host, port=port, debug=debug)

if __name__ == '__main__':
    init_db()
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5000
    run_server(port=port, debug=True)
