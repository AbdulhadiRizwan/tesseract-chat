#!/bin/bash
cd /home/abdulhadi/Documents/chat-app
python3 client.py 2>/tmp/tesseract-error.log
if [ $? -ne 0 ]; then
    xterm -e "cat /tmp/tesseract-error.log; echo 'Press Enter to exit'; read"
fi
