import sys
import os
import threading
import time
import tempfile
import json
from datetime import datetime
from io import BytesIO

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtMultimedia import *
from PySide6.QtNetwork import *

import socketio
import requests

HAS_AUDIO = True
try:
    import sounddevice as sd
    import soundfile as sf
    import numpy as np
except ImportError:
    HAS_AUDIO = False

SERVER_PORT = 5000

def get_local_ip():
    try:
        s = socketio.Client()
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return '127.0.0.1'

class SocketClient(QObject):
    connected = Signal()
    disconnected = Signal()
    login_result = Signal(dict)
    register_result = Signal(dict)
    new_message = Signal(dict)
    conversations_loaded = Signal(list)
    messages_loaded = Signal(list)
    search_results = Signal(list)
    conversation_started = Signal(dict)
    user_online = Signal(str)
    user_offline = Signal(str)
    online_users = Signal(list)
    connection_error = Signal(str)

    def __init__(self):
        super().__init__()
        self.sio = socketio.Client(reconnection=True, reconnection_delay=1)
        self.server_url = ''
        self.user_id = None
        self.username = None
        self._setup_handlers()

    def _setup_handlers(self):
        @self.sio.on('connect')
        def on_connect():
            self.connected.emit()

        @self.sio.on('disconnect')
        def on_disconnect():
            self.disconnected.emit()

        @self.sio.on('login_result')
        def on_login(data):
            if data.get('success'):
                self.user_id = data['user']['id']
                self.username = data['user']['username']
            self.login_result.emit(data)

        @self.sio.on('register_result')
        def on_register(data):
            self.register_result.emit(data)

        @self.sio.on('new_message')
        def on_message(data):
            self.new_message.emit(data)

        @self.sio.on('conversations')
        def on_conversations(data):
            self.conversations_loaded.emit(data.get('conversations', []))

        @self.sio.on('messages')
        def on_messages(data):
            self.messages_loaded.emit(data.get('messages', []))

        @self.sio.on('search_results')
        def on_search(data):
            self.search_results.emit(data.get('users', []))

        @self.sio.on('conversation_started')
        def on_conv_started(data):
            self.conversation_started.emit(data)

        @self.sio.on('user_online')
        def on_user_online(data):
            self.user_online.emit(data['username'])

        @self.sio.on('user_offline')
        def on_user_offline(data):
            self.user_offline.emit(data['username'])

        @self.sio.on('online_users')
        def on_online(data):
            self.online_users.emit(data)

    def connect_to_server(self, url):
        self.server_url = url
        t = threading.Thread(target=self._connect, daemon=True)
        t.start()

    def _connect(self):
        try:
            self.sio.connect(self.server_url, transports=['websocket', 'polling'])
        except Exception as e:
            self.connection_error.emit(str(e))

    def disconnect(self):
        if self.sio.connected:
            self.sio.disconnect()

    def emit(self, event, data=None):
        if data is None:
            data = {}
        self.sio.emit(event, data)


class LoginDialog(QDialog):
    logged_in = Signal(dict)
    server_started = Signal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle('Tesseract - Login')
        self.setMinimumSize(420, 480)
        self.resize(480, 560)
        self.setStyleSheet('''
            QDialog { background: #1A1A2E; }
            QLabel { color: #E0E0E8; font-size: 13px; }
            QLineEdit {
                background: #1E1E30; color: #E0E0E8; border: 1px solid #2A2A3E;
                border-radius: 8px; padding: 10px 14px; font-size: 14px;
            }
            QLineEdit:focus { border-color: #6C63FF; }
            QPushButton {
                border-radius: 8px; padding: 10px; font-size: 14px; font-weight: 600;
            }
            QPushButton#primary {
                background: #6C63FF; color: white; border: none;
            }
            QPushButton#primary:hover { background: #5A52D5; }
            QPushButton#secondary {
                background: transparent; color: #6C63FF; border: 1px solid #6C63FF;
            }
            QPushButton#secondary:hover { background: rgba(108,99,255,0.1); }
            QPushButton#start {
                background: #4CAF50; color: white; border: none;
            }
            QPushButton#start:hover { background: #43A047; }
            QLabel#error { color: #EF5350; font-size: 12px; }
            QLabel#success { color: #66BB6A; font-size: 12px; }
        ''')
        self.sio_client = None
        self.server_process = None
        self.logged_in_user = None
        self.logged_in.connect(self._on_logged_in)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 30, 40, 30)
        layout.setSpacing(12)

        title = QLabel('🔷 Tesseract')
        title.setStyleSheet('font-size: 28px; font-weight: 700; color: #6C63FF;')
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel('Connect & start chatting')
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet('color: #8888A8; font-size: 13px; margin-bottom: 10px;')
        layout.addWidget(subtitle)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet('background: #2A2A3E; max-height: 1px; margin: 5px 0;')
        layout.addWidget(sep)

        layout.addWidget(QLabel('Server Connection'))

        ip_layout = QHBoxLayout()
        self.ip_input = QLineEdit(get_local_ip())
        self.ip_input.setPlaceholderText('Server IP')
        self.port_input = QLineEdit(str(SERVER_PORT))
        self.port_input.setFixedWidth(80)
        ip_layout.addWidget(self.ip_input)
        ip_layout.addWidget(self.port_input)
        layout.addLayout(ip_layout)

        btn_layout = QHBoxLayout()
        self.connect_btn = QPushButton('Connect')
        self.connect_btn.setObjectName('primary')
        self.start_btn = QPushButton('Start Server')
        self.start_btn.setObjectName('start')
        btn_layout.addWidget(self.connect_btn)
        btn_layout.addWidget(self.start_btn)
        layout.addLayout(btn_layout)

        self.conn_status = QLabel('')
        self.conn_status.setObjectName('success')
        layout.addWidget(self.conn_status)

        sep2 = QFrame()
        sep2.setFrameShape(QFrame.HLine)
        sep2.setStyleSheet('background: #2A2A3E; max-height: 1px; margin: 5px 0;')
        layout.addWidget(sep2)

        layout.addWidget(QLabel('Account'))

        self.user_input = QLineEdit()
        self.user_input.setPlaceholderText('Username')
        layout.addWidget(self.user_input)

        self.pass_input = QLineEdit()
        self.pass_input.setPlaceholderText('Password')
        self.pass_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.pass_input)

        btn_layout2 = QHBoxLayout()
        self.login_btn = QPushButton('Login')
        self.login_btn.setObjectName('primary')
        self.login_btn.setEnabled(False)
        self.register_btn = QPushButton('Register')
        self.register_btn.setObjectName('secondary')
        self.register_btn.setEnabled(False)
        btn_layout2.addWidget(self.login_btn)
        btn_layout2.addWidget(self.register_btn)
        layout.addLayout(btn_layout2)

        self.error_label = QLabel('')
        self.error_label.setObjectName('error')
        layout.addWidget(self.error_label)

        layout.addStretch()

        self.connect_btn.clicked.connect(self.connect_to_server)
        self.start_btn.clicked.connect(self.start_server)
        self.login_btn.clicked.connect(self.login)
        self.register_btn.clicked.connect(self.register)
        self.user_input.returnPressed.connect(self.login)
        self.pass_input.returnPressed.connect(self.login)

    def start_server(self):
        self.error_label.setText('')
        self.conn_status.setText('Starting server...')
        self.conn_status.setObjectName('success')
        self.conn_status.setStyleSheet('color: #66BB6A; font-size: 12px;')
        QApplication.processEvents()

        if self.server_process:
            self.server_process.terminate()
            self.server_process.waitForFinished(2000)

        port = int(self.port_input.text())
        self.server_process = QProcess(self)
        script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'server.py')
        self.server_process.setWorkingDirectory(os.path.dirname(script_path))
        self.server_process.start(sys.executable, [script_path, str(port)])

        if not self.server_process.waitForStarted(3000):
            self.conn_status.setText('Failed to start server')
            self.conn_status.setObjectName('error')
            self.conn_status.setStyleSheet('color: #EF5350; font-size: 12px;')
            return

        QTimer.singleShot(1500, lambda: self._try_connect_after_start(port))

    def _try_connect_after_start(self, port, attempt=0):
        if attempt > 5:
            self.conn_status.setText('Server started but not ready yet')
            return
        try:
            r = requests.get(f'http://{self.ip_input.text()}:{port}/health', timeout=1)
            if r.status_code == 200:
                self.connect_to_server()
                return
        except:
            pass
        QTimer.singleShot(1000, lambda: self._try_connect_after_start(port, attempt + 1))

    def connect_to_server(self):
        self.error_label.setText('')
        self.conn_status.setText('Connecting...')
        QApplication.processEvents()

        url = f'http://{self.ip_input.text()}:{self.port_input.text()}'
        self.sio_client = SocketClient()
        self.sio_client.connection_error.connect(self.on_connection_error)
        self.sio_client.connected.connect(self.on_connected)
        self.sio_client.login_result.connect(self.on_login_result)
        self.sio_client.register_result.connect(self.on_register_result)
        self.sio_client.connect_to_server(url)

    def on_connection_error(self, err):
        self.conn_status.setText(f'Connection failed: {err}')
        self.conn_status.setObjectName('error')
        self.conn_status.setStyleSheet('color: #EF5350; font-size: 12px;')

    def on_connected(self):
        self.conn_status.setText('✅ Connected to server')
        self.conn_status.setObjectName('success')
        self.conn_status.setStyleSheet('color: #66BB6A; font-size: 12px;')
        self.login_btn.setEnabled(True)
        self.register_btn.setEnabled(True)

    def login(self):
        username = self.user_input.text().strip()
        password = self.pass_input.text()
        if not username or not password:
            self.error_label.setText('Enter username and password')
            return
        self.error_label.setText('')
        self.login_btn.setEnabled(False)
        self.register_btn.setEnabled(False)
        self.conn_status.setText('Logging in...')
        self.sio_client.emit('login', {'username': username, 'password': password})

    def register(self):
        username = self.user_input.text().strip()
        password = self.pass_input.text()
        if not username or not password:
            self.error_label.setText('Enter username and password')
            return
        if len(password) < 4:
            self.error_label.setText('Password must be at least 4 characters')
            return
        self.error_label.setText('')
        self.login_btn.setEnabled(False)
        self.register_btn.setEnabled(False)
        self.conn_status.setText('Registering...')
        self.sio_client.emit('register', {'username': username, 'password': password})

    def on_login_result(self, data):
        self.login_btn.setEnabled(True)
        self.register_btn.setEnabled(True)
        if data.get('success'):
            self.logged_in.emit(data['user'])
            self.accept()
        else:
            self.error_label.setText(data.get('error', 'Login failed'))

    def on_register_result(self, data):
        self.login_btn.setEnabled(True)
        self.register_btn.setEnabled(True)
        if data.get('success'):
            self.error_label.setObjectName('success')
            self.error_label.setStyleSheet('color: #66BB6A; font-size: 12px;')
            self.error_label.setText('Account created! You can now login.')
        else:
            self.error_label.setText(data.get('error', 'Registration failed'))

    def _on_logged_in(self, user):
        self.logged_in_user = user

    def closeEvent(self, event):
        if self.server_process:
            self.server_process.terminate()
            self.server_process.waitForFinished(2000)
        if self.sio_client:
            self.sio_client.disconnect()
        event.accept()


class MessageBubble(QWidget):
    def __init__(self, message, is_own=False, client=None):
        super().__init__()
        self.message = message
        self.is_own = is_own
        self.client = client
        self.init_ui()

    def init_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 2, 10, 2)
        layout.setSpacing(8)

        container = QVBoxLayout()
        container.setSpacing(4)

        bubble = QFrame()
        bubble.setStyleSheet(f'''
            QFrame {{
                background: {'#6C63FF' if self.is_own else '#1E1E30'};
                border-radius: 12px;
                border-bottom-{'right' if self.is_own else 'left'}-radius: 4px;
                padding: 8px 12px;
            }}
        ''')

        bl = QVBoxLayout(bubble)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(4)

        msg_type = self.message.get('message_type', 'text')
        content = self.message.get('content', '')
        file_url = self.message.get('file_url', '')
        file_name = self.message.get('file_name', '')
        duration = self.message.get('duration')

        if msg_type == 'text':
            lbl = QLabel(content)
            lbl.setWordWrap(True)
            lbl.setStyleSheet(f'color: {"#FFFFFF" if self.is_own else "#E0E0E8"}; font-size: 14px; background: transparent;')
            bl.addWidget(lbl)

        elif msg_type in ('image',):
            preview = QLabel()
            preview.setFixedSize(200, 150)
            preview.setCursor(Qt.PointingHandCursor)
            preview.setStyleSheet('background: #0D0D1A; border-radius: 8px;')
            bl.addWidget(preview)

            if file_url and self.client:
                url = self.client.server_url + file_url
                t = threading.Thread(target=self._load_image, args=(preview, url), daemon=True)
                t.start()

            preview.mousePressEvent = lambda e: self._open_file(file_url, file_name)

        elif msg_type == 'video':
            btn = QPushButton(f'▶ Play Video: {file_name or "Video"}')
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(f'''
                QPushButton {{
                    background: #0D0D1A; color: #E0E0E8; border: none;
                    border-radius: 8px; padding: 20px; font-size: 13px;
                    text-align: center;
                }}
                QPushButton:hover {{ background: #1A1A2E; }}
            ''')
            btn.clicked.connect(lambda: self._open_file(file_url, file_name))
            bl.addWidget(btn)

        elif msg_type == 'voice':
            vb = QHBoxLayout()
            play_btn = QPushButton('▶')
            play_btn.setFixedSize(36, 36)
            play_btn.setStyleSheet(f'''
                QPushButton {{
                    background: {'rgba(255,255,255,0.2)' if self.is_own else '#6C63FF'};
                    color: white; border: none; border-radius: 18px;
                    font-size: 14px;
                }}
                QPushButton:hover {{ background: {'rgba(255,255,255,0.3)' if self.is_own else '#5A52D5'}; }}
            ''')
            dur_text = f'{duration:.1f}s' if duration else '0:00'
            dur_label = QLabel(f'🎤 Voice ({dur_text})')
            dur_label.setStyleSheet(f'color: {"#FFFFFF" if self.is_own else "#E0E0E8"}; font-size: 13px; background: transparent;')
            vb.addWidget(play_btn)
            vb.addWidget(dur_label)
            vb.addStretch()
            bl.addLayout(vb)

            if file_url:
                play_btn.clicked.connect(lambda: self._play_audio(file_url))

        elif msg_type == 'audio':
            ab = QHBoxLayout()
            play_btn = QPushButton('▶')
            play_btn.setFixedSize(36, 36)
            play_btn.setStyleSheet(f'''
                QPushButton {{
                    background: {'rgba(255,255,255,0.2)' if self.is_own else '#6C63FF'};
                    color: white; border: none; border-radius: 18px; font-size: 14px;
                }}
                QPushButton:hover {{ background: {'rgba(255,255,255,0.3)' if self.is_own else '#5A52D5'}; }}
            ''')
            info = QLabel(f'🎵 {file_name or "Audio"}')
            info.setStyleSheet(f'color: {"#FFFFFF" if self.is_own else "#E0E0E8"}; font-size: 13px; background: transparent;')
            ab.addWidget(play_btn)
            ab.addWidget(info)
            ab.addStretch()
            bl.addLayout(ab)

            if file_url:
                play_btn.clicked.connect(lambda: self._play_audio(file_url))

        elif msg_type == 'file':
            fl = QHBoxLayout()
            icon = QLabel('📎')
            icon.setStyleSheet('background: transparent; font-size: 20px;')
            name = QLabel(file_name or 'File')
            name.setStyleSheet(f'color: {"#FFFFFF" if self.is_own else "#E0E0E8"}; font-size: 13px; background: transparent;')
            fl.addWidget(icon)
            fl.addWidget(name)
            fl.addStretch()
            bl.addLayout(fl)
            bubble.mousePressEvent = lambda e: self._open_file(file_url, file_name)

        time_lbl = QLabel(self._format_time(self.message.get('timestamp', '')))
        time_lbl.setStyleSheet(f'color: {"rgba(255,255,255,0.5)" if self.is_own else "#6B6B88"}; font-size: 11px; background: transparent;')
        container.addWidget(bubble)
        container.addWidget(time_lbl)

        if self.is_own:
            layout.addStretch()
            layout.addLayout(container)
        else:
            layout.addLayout(container)
            layout.addStretch()

    def _format_time(self, ts):
        if not ts:
            return ''
        try:
            dt = datetime.fromisoformat(ts.replace('T', ' ').split('.')[0])
            return dt.strftime('%I:%M %p')
        except:
            return ts[-8:-3] if len(ts) > 8 else ''

    def _load_image(self, label, url):
        try:
            r = requests.get(url, timeout=10)
            if r.status_code == 200:
                pixmap = QPixmap()
                pixmap.loadFromData(r.content)
                scaled = pixmap.scaled(200, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                QTimer.singleShot(0, lambda: label.setPixmap(scaled))
        except:
            pass

    def _open_file(self, file_url, file_name):
        if not file_url or not self.client:
            return
        url = self.client.server_url + file_url
        QDesktopServices.openUrl(QUrl(url))

    def _play_audio(self, file_url):
        if not file_url or not self.client:
            return
        url = self.client.server_url + file_url
        QDesktopServices.openUrl(QUrl(url))


class ChatPanel(QWidget):
    def __init__(self, client):
        super().__init__()
        self.client = client
        self.current_conv_id = None
        self.current_other_user = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.header = QFrame()
        self.header.setFixedHeight(52)
        self.header.setStyleSheet('background: #1E1E30; border-bottom: 1px solid #2A2A3E;')
        hl = QHBoxLayout(self.header)
        hl.setContentsMargins(12, 0, 12, 0)

        self.back_btn = QPushButton('←')
        self.back_btn.setFixedSize(32, 32)
        self.back_btn.setStyleSheet('''
            QPushButton { background: transparent; color: #E0E0E8; border: none;
                          border-radius: 16px; font-size: 16px; }
            QPushButton:hover { background: #2A2A3E; }
        ''')
        self.back_btn.hide()

        self.header_title = QLabel('Select a conversation')
        self.header_title.setStyleSheet('color: #E0E0E8; font-size: 15px; font-weight: 600;')

        self.online_dot = QLabel('')
        self.online_dot.setFixedSize(10, 10)
        self.online_dot.setStyleSheet('background: #4CAF50; border-radius: 5px;')
        self.online_dot.hide()

        hl.addWidget(self.back_btn)
        hl.addWidget(self.online_dot)
        hl.addSpacing(6)
        hl.addWidget(self.header_title)
        hl.addStretch()

        layout.addWidget(self.header)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet('''
            QScrollArea { border: none; background: #1A1A2E; }
            QScrollBar:vertical { background: #1A1A2E; width: 6px; }
            QScrollBar::handle:vertical { background: #2A2A3E; border-radius: 3px; }
        ''')
        self.messages_container = QWidget()
        self.messages_container.setStyleSheet('background: #1A1A2E;')
        self.messages_layout = QVBoxLayout(self.messages_container)
        self.messages_layout.setAlignment(Qt.AlignBottom)
        self.messages_layout.setSpacing(2)
        scroll.setWidget(self.messages_container)
        layout.addWidget(scroll, 1)

        input_area = QFrame()
        input_area.setStyleSheet('background: #1E1E30; border-top: 1px solid #2A2A3E;')
        input_area.setFixedHeight(56)
        il = QHBoxLayout(input_area)
        il.setContentsMargins(8, 6, 8, 6)
        il.setSpacing(6)

        self.attach_btn = QPushButton('📎')
        self.attach_btn.setFixedSize(40, 40)
        self.attach_btn.setStyleSheet('''
            QPushButton { background: transparent; color: #E0E0E8;
                          border: none; border-radius: 20px; font-size: 18px; }
            QPushButton:hover { background: #2A2A3E; }
        ''')
        self.attach_btn.clicked.connect(self.attach_file)

        self.msg_input = QLineEdit()
        self.msg_input.setPlaceholderText('Type a message...')
        self.msg_input.setStyleSheet('''
            QLineEdit {
                background: #1A1A2E; color: #E0E0E8; border: 1px solid #2A2A3E;
                border-radius: 20px; padding: 8px 16px; font-size: 14px;
            }
            QLineEdit:focus { border-color: #6C63FF; }
        ''')
        self.msg_input.returnPressed.connect(self.send_text)

        self.voice_btn = QPushButton('🎤')
        self.voice_btn.setFixedSize(40, 40)
        self.voice_btn.setStyleSheet('''
            QPushButton { background: transparent; color: #E0E0E8;
                          border: none; border-radius: 20px; font-size: 18px; }
            QPushButton:hover { background: #2A2A3E; }
            QPushButton#recording { background: #E53935; color: white; }
        ''')
        self.voice_btn.clicked.connect(self.toggle_recording)

        self.send_btn = QPushButton('➤')
        self.send_btn.setFixedSize(40, 40)
        self.send_btn.setStyleSheet('''
            QPushButton { background: #6C63FF; color: white;
                          border: none; border-radius: 20px; font-size: 16px; }
            QPushButton:hover { background: #5A52D5; }
        ''')
        self.send_btn.clicked.connect(self.send_text)

        il.addWidget(self.attach_btn)
        il.addWidget(self.msg_input, 1)
        il.addWidget(self.voice_btn)
        il.addWidget(self.send_btn)

        layout.addWidget(input_area)

        self.is_recording = False
        self.recording_thread = None

    def set_conversation(self, conv_id, other_username, other_user_id, online=False):
        self.current_conv_id = conv_id
        self.current_other_user = other_username
        self.header_title.setText(other_username)
        self.back_btn.show()
        self.online_dot.setVisible(online)
        self.clear_messages()
        self.load_messages()

    def clear_messages(self):
        while self.messages_layout.count():
            item = self.messages_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def load_messages(self):
        if not self.current_conv_id:
            return
        self.client.emit('get_messages', {'conversation_id': self.current_conv_id})

    def display_messages(self, messages):
        self.clear_messages()
        user_id = self.client.user_id
        for msg in messages:
            is_own = msg['sender_id'] == user_id
            bubble = MessageBubble(msg, is_own, self.client)
            self.messages_layout.addWidget(bubble)
        self.messages_layout.addStretch()

    def add_message(self, msg):
        is_own = msg['sender_id'] == self.client.user_id
        conv_match = msg['conversation_id'] == self.current_conv_id
        if conv_match:
            bubble = MessageBubble(msg, is_own, self.client)
            self.messages_layout.insertWidget(self.messages_layout.count() - 1, bubble)

    def send_text(self):
        text = self.msg_input.text().strip()
        if not text or not self.current_conv_id:
            return
        self.client.emit('send_message', {
            'conversation_id': self.current_conv_id,
            'content': text,
            'message_type': 'text'
        })
        self.msg_input.clear()

    def attach_file(self):
        if not self.current_conv_id:
            return
        file_path, _ = QFileDialog.getOpenFileName(
            self, 'Select File', '',
            'Media (*.jpg *.jpeg *.png *.gif *.mp4 *.webm *.mov *.mp3 *.wav *.ogg *.m4a)'
        )
        if not file_path:
            return

        ext = file_path.rsplit('.', 1)[-1].lower() if '.' in file_path else ''
        img_exts = {'jpg', 'jpeg', 'png', 'gif'}
        vid_exts = {'mp4', 'webm', 'mov'}
        aud_exts = {'mp3', 'wav', 'ogg', 'm4a'}

        if ext in img_exts:
            msg_type = 'image'
        elif ext in vid_exts:
            msg_type = 'video'
        elif ext in aud_exts:
            msg_type = 'audio'
        else:
            msg_type = 'file'

        file_name = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)

        self.upload_and_send(file_path, msg_type, file_name, file_size)

    def upload_and_send(self, file_path, msg_type, file_name, file_size):
        url = f'{self.client.server_url}/upload'
        try:
            with open(file_path, 'rb') as f:
                r = requests.post(url, files={'file': (file_name, f)}, timeout=60)
            if r.status_code == 200:
                data = r.json()
                self.client.emit('send_message', {
                    'conversation_id': self.current_conv_id,
                    'message_type': msg_type,
                    'file_url': data['url'],
                    'file_name': data['original_name'],
                    'file_size': data['size'],
                    'content': ''
                })
            else:
                QMessageBox.warning(self, 'Upload Failed', f'Server error: {r.status_code}')
        except Exception as e:
            QMessageBox.warning(self, 'Upload Failed', str(e))

    def toggle_recording(self):
        if not HAS_AUDIO:
            QMessageBox.information(self, 'Voice Recording',
                'Install sounddevice: pip install sounddevice soundfile numpy')
            return
        if not self.current_conv_id:
            return
        if not self.is_recording:
            self.start_recording()
        else:
            self.stop_recording()

    def start_recording(self):
        self.is_recording = True
        self.voice_btn.setText('🔴')
        self.voice_btn.setObjectName('recording')
        self.voice_btn.setStyleSheet('''
            QPushButton#recording { background: #E53935; color: white;
                                    border: none; border-radius: 20px; font-size: 16px; }
        ''')
        self.recording_data = []
        self.sample_rate = 44100

        def record():
            with sd.InputStream(samplerate=self.sample_rate, channels=1,
                                callback=self.audio_callback):
                while self.is_recording:
                    sd.sleep(100)

        self.recording_thread = threading.Thread(target=record, daemon=True)
        self.recording_thread.start()

    def audio_callback(self, indata, frames, time_info, status):
        if self.is_recording:
            self.recording_data.append(indata.copy())

    def stop_recording(self):
        self.is_recording = False
        self.voice_btn.setText('🎤')
        self.voice_btn.setObjectName('')
        self.voice_btn.setStyleSheet('''
            QPushButton { background: transparent; color: #E0E0E8;
                          border: none; border-radius: 20px; font-size: 18px; }
            QPushButton:hover { background: #2A2A3E; }
        ''')

        if self.recording_thread:
            self.recording_thread.join(timeout=2)
            self.recording_thread = None

        if not self.recording_data:
            return

        try:
            audio = np.concatenate(self.recording_data, axis=0)
            duration = len(audio) / self.sample_rate
            tmp = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
            tmp_path = tmp.name
            tmp.close()
            sf.write(tmp_path, audio, self.sample_rate)
            file_size = os.path.getsize(tmp_path)
            self.upload_and_send(tmp_path, 'voice', 'voice.wav', file_size)
            self.recording_data = []
        except Exception as e:
            QMessageBox.warning(self, 'Recording Failed', str(e))


class ConversationListPanel(QWidget):
    conversation_selected = Signal(int, str, int, bool)

    def __init__(self, client):
        super().__init__()
        self.client = client
        self.conversations = []
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        search_frame = QFrame()
        search_frame.setStyleSheet('background: #1E1E30; border-bottom: 1px solid #2A2A3E;')
        search_frame.setFixedHeight(48)
        sl = QHBoxLayout(search_frame)
        sl.setContentsMargins(10, 6, 10, 6)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText('🔍 Search conversations...')
        self.search_input.setStyleSheet('''
            QLineEdit {
                background: #1A1A2E; color: #E0E0E8; border: 1px solid #2A2A3E;
                border-radius: 8px; padding: 6px 10px; font-size: 13px;
            }
            QLineEdit:focus { border-color: #6C63FF; }
        ''')
        self.search_input.textChanged.connect(self.filter_list)
        sl.addWidget(self.search_input)

        layout.addWidget(search_frame)

        self.list_widget = QListWidget()
        self.list_widget.setStyleSheet('''
            QListWidget {
                background: #1A1A2E; border: none; outline: none;
            }
            QListWidget::item {
                background: #1A1A2E; color: #E0E0E8;
                border-bottom: 1px solid #2A2A3E;
                padding: 12px 14px;
            }
            QListWidget::item:selected {
                background: rgba(108, 99, 255, 0.15);
                border-left: 3px solid #6C63FF;
            }
            QListWidget::item:hover {
                background: #1E1E30;
            }
        ''')
        self.list_widget.currentRowChanged.connect(self.on_selection)
        layout.addWidget(self.list_widget, 1)

    def set_conversations(self, convs):
        self.conversations = convs
        self.refresh_list()

    def refresh_list(self):
        self.list_widget.blockSignals(True)
        self.list_widget.clear()
        query = self.search_input.text().strip().lower()
        for conv in self.conversations:
            if query and query not in conv['other_username'].lower():
                continue
            item = QListWidgetItem()
            name = conv['other_username']
            last = conv.get('last_message', '')
            time_str = ''
            if conv.get('last_time'):
                try:
                    dt = datetime.fromisoformat(str(conv['last_time']).replace('T', ' ').split('.')[0])
                    now = datetime.now()
                    if dt.date() == now.date():
                        time_str = dt.strftime('%I:%M %p')
                    else:
                        time_str = dt.strftime('%b %d')
                except:
                    time_str = ''
            online = conv.get('other_online', False)
            dot = '🟢' if online else '⚪'
            display = f'{dot}  {name}\n{last[:50]}{"..." if len(last) > 50 else ""}'
            item.setText(display)
            item.setData(Qt.UserRole, conv)
            self.list_widget.addItem(item)
        self.list_widget.blockSignals(False)

    def filter_list(self):
        self.refresh_list()

    def on_selection(self, index):
        item = self.list_widget.item(index)
        if item:
            conv = item.data(Qt.UserRole)
            if conv:
                self.conversation_selected.emit(
                    conv['conversation_id'],
                    conv['other_username'],
                    conv['other_user_id'],
                    conv.get('other_online', False)
                )


class DMsPage(QWidget):
    def __init__(self, client):
        super().__init__()
        self.client = client
        self.client.conversations_loaded.connect(self.on_conversations)
        self.client.messages_loaded.connect(self.on_messages)
        self.client.new_message.connect(self.on_new_message)
        self.init_ui()

    def init_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.conv_list = ConversationListPanel(self.client)
        self.conv_list.setFixedWidth(280)
        self.conv_list.conversation_selected.connect(self.open_conversation)
        layout.addWidget(self.conv_list)

        sep = QFrame()
        sep.setFixedWidth(1)
        sep.setStyleSheet('background: #2A2A3E;')
        layout.addWidget(sep)

        self.chat = ChatPanel(self.client)
        layout.addWidget(self.chat, 1)

    def open_conversation(self, conv_id, username, user_id, online):
        self.chat.set_conversation(conv_id, username, user_id, online)

    def on_conversations(self, convs):
        self.conv_list.set_conversations(convs)

    def on_messages(self, msgs):
        self.chat.display_messages(msgs)

    def on_new_message(self, data):
        msg = data.get('message', data)
        self.chat.add_message(msg)
        self.client.emit('get_conversations')

    def set_other_online(self, username, online):
        if self.chat.current_other_user == username:
            self.chat.online_dot.setVisible(online)


class SearchPage(QWidget):
    def __init__(self, client):
        super().__init__()
        self.client = client
        self.client.search_results.connect(self.on_results)
        self.client.conversation_started.connect(self.on_conv_started)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        title = QLabel('🔍 Search Users')
        title.setStyleSheet('color: #E0E0E8; font-size: 20px; font-weight: 700;')
        layout.addWidget(title)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText('Search by username...')
        self.search_input.setStyleSheet('''
            QLineEdit {
                background: #1E1E30; color: #E0E0E8; border: 1px solid #2A2A3E;
                border-radius: 10px; padding: 12px 16px; font-size: 15px;
            }
            QLineEdit:focus { border-color: #6C63FF; }
        ''')
        self.search_input.textChanged.connect(self.do_search)
        layout.addWidget(self.search_input)

        self.results_list = QListWidget()
        self.results_list.setStyleSheet('''
            QListWidget {
                background: transparent; border: none; outline: none;
            }
            QListWidget::item {
                background: #1E1E30; color: #E0E0E8;
                border-radius: 10px; margin: 4px 0; padding: 14px;
            }
            QListWidget::item:hover { background: #2A2A3E; }
        ''')
        layout.addWidget(self.results_list, 1)

    def do_search(self, query):
        if len(query.strip()) < 1:
            self.results_list.clear()
            return
        self.client.emit('search_users', {'query': query.strip()})

    def on_results(self, users):
        self.results_list.clear()
        for user in users:
            item = QListWidgetItem()
            online = user.get('online', False)
            dot = '🟢' if online else '⚪'
            text = f'{dot}  {user["username"]}'
            item.setText(text)
            item.setData(Qt.UserRole, user)
            self.results_list.addItem(item)

        if not users:
            item = QListWidgetItem('No users found')
            item.setFlags(Qt.NoItemFlags)
            self.results_list.addItem(item)

        self.results_list.itemClicked.connect(self.start_dm)

    def start_dm(self, item):
        user = item.data(Qt.UserRole)
        if not user:
            return
        self.client.emit('start_conversation', {'username': user['username']})

    def on_conv_started(self, data):
        if data.get('success'):
            conv = data['conversation']
            QMessageBox.information(self, 'DM Started',
                f'Conversation with {conv["other_username"]} is ready!')
        else:
            QMessageBox.warning(self, 'Error', data.get('error', 'Could not start conversation'))


class ProfilePage(QWidget):
    logout_requested = Signal()

    def __init__(self, client, user_data):
        super().__init__()
        self.client = client
        self.user_data = user_data
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(16)

        avatar = QLabel('👤')
        avatar.setStyleSheet('font-size: 64px;')
        avatar.setAlignment(Qt.AlignCenter)
        layout.addWidget(avatar)

        name = QLabel(self.user_data.get('username', ''))
        name.setStyleSheet('color: #E0E0E8; font-size: 24px; font-weight: 700;')
        name.setAlignment(Qt.AlignCenter)
        layout.addWidget(name)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet('background: #2A2A3E; max-height: 1px; margin: 10px 0;')
        layout.addWidget(sep)

        info = QLabel(f'User ID: {self.user_data.get("id", "")}')
        info.setStyleSheet('color: #6B6B88; font-size: 13px;')
        info.setAlignment(Qt.AlignCenter)
        layout.addWidget(info)

        if self.user_data.get('created_at'):
            created = QLabel(f'Joined: {str(self.user_data["created_at"])[:10]}')
            created.setStyleSheet('color: #6B6B88; font-size: 13px;')
            created.setAlignment(Qt.AlignCenter)
            layout.addWidget(created)

        layout.addStretch()

        logout_btn = QPushButton('🚪 Logout')
        logout_btn.setFixedHeight(48)
        logout_btn.setStyleSheet('''
            QPushButton {
                background: transparent; color: #EF5350; border: 1px solid #EF5350;
                border-radius: 10px; font-size: 15px; font-weight: 600;
            }
            QPushButton:hover { background: rgba(239,83,80,0.1); }
        ''')
        logout_btn.clicked.connect(self.logout_requested.emit)
        layout.addWidget(logout_btn)


class MainWindow(QMainWindow):
    def __init__(self, client, user_data, server_process=None):
        super().__init__()
        self.client = client
        self.user_data = user_data
        self.server_process = server_process
        self.setWindowTitle(f'Tesseract - {user_data["username"]}')
        self.setMinimumSize(900, 600)
        self.resize(1000, 680)
        self.setStyleSheet('QMainWindow { background: #1A1A2E; }')
        self.init_ui()
        self.setup_socket_handlers()
        self.client.emit('get_conversations')

    def init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        top_bar = QFrame()
        top_bar.setFixedHeight(48)
        top_bar.setStyleSheet('background: #1E1E30; border-bottom: 1px solid #2A2A3E;')
        tl = QHBoxLayout(top_bar)
        tl.setContentsMargins(16, 0, 16, 0)

        title = QLabel('🔷 Tesseract')
        title.setStyleSheet('color: #6C63FF; font-size: 16px; font-weight: 700;')
        tl.addWidget(title)
        tl.addStretch()

        self.status_dot = QLabel('')
        self.status_dot.setFixedSize(8, 8)
        self.status_dot.setStyleSheet('background: #4CAF50; border-radius: 4px;')
        tl.addWidget(self.status_dot)

        conn_label = QLabel('Connected')
        conn_label.setStyleSheet('color: #66BB6A; font-size: 12px;')
        tl.addWidget(conn_label)

        layout.addWidget(top_bar)

        self.stack = QStackedWidget()
        layout.addWidget(self.stack, 1)

        self.dms_page = DMsPage(self.client)
        self.search_page = SearchPage(self.client)
        self.profile_page = ProfilePage(self.client, self.user_data)
        self.profile_page.logout_requested.connect(self.logout)

        self.stack.addWidget(self.dms_page)
        self.stack.addWidget(self.search_page)
        self.stack.addWidget(self.profile_page)

        bottom_nav = QFrame()
        bottom_nav.setFixedHeight(56)
        bottom_nav.setStyleSheet('background: #1E1E30; border-top: 1px solid #2A2A3E;')
        bl = QHBoxLayout(bottom_nav)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(0)

        self.nav_btns = []
        for i, (icon, label) in enumerate([
            ('💬', 'DMs'), ('🔍', 'Search'), ('👤', 'Profile')
        ]):
            btn = QPushButton(f'{icon}  {label}')
            btn.setCheckable(True)
            btn.setFixedHeight(56)
            btn.setStyleSheet('''
                QPushButton {
                    background: transparent; color: #6B6B88; border: none;
                    border-top: 2px solid transparent; font-size: 13px;
                }
                QPushButton:checked {
                    color: #6C63FF; border-top: 2px solid #6C63FF;
                    background: rgba(108,99,255,0.08);
                }
                QPushButton:hover {
                    color: #E0E0E8;
                }
            ''')
            btn.clicked.connect(lambda checked, idx=i: self.switch_page(idx))
            bl.addWidget(btn, 1)
            self.nav_btns.append(btn)

        self.nav_btns[0].setChecked(True)
        layout.addWidget(bottom_nav)

    def switch_page(self, idx):
        for i, btn in enumerate(self.nav_btns):
            btn.setChecked(i == idx)
        self.stack.setCurrentIndex(idx)
        if idx == 0:
            self.client.emit('get_conversations')

    def setup_socket_handlers(self):
        self.client.user_online.connect(self.on_user_online)
        self.client.user_offline.connect(self.on_user_offline)
        self.client.new_message.connect(self.on_new_message)

    def on_user_online(self, username):
        self.dms_page.set_other_online(username, True)

    def on_user_offline(self, username):
        self.dms_page.set_other_online(username, False)

    def on_new_message(self, data):
        msg = data.get('message', data)
        self.client.emit('get_conversations')

    def logout(self):
        self.client.disconnect()
        self.close()

    def closeEvent(self, event):
        if self.server_process:
            self.server_process.terminate()
            self.server_process.waitForFinished(2000)
        self.client.disconnect()
        event.accept()


class ClientApp:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.app.setStyle('Fusion')
        self.client = None

    def run(self):
        dialog = LoginDialog()
        if dialog.exec() != QDialog.Accepted:
            sys.exit(0)

        client = dialog.sio_client
        user_data = dialog.logged_in_user

        if not client or not user_data:
            sys.exit(0)

        self.client = client
        window = MainWindow(client, user_data, dialog.server_process)
        dialog.server_process = None  # ownership transferred
        window.show()
        sys.exit(self.app.exec())


if __name__ == '__main__':
    app = ClientApp()
    app.run()
